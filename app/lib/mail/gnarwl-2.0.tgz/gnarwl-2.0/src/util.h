/**
 * Out Of Memory - print error message to syslog, exit ungracefully
 */
void oom();

/**
 * Replace variables in text.
 * @param txt the text buffer
 * @param s string representing the variable
 * @param r replacement for s
 * If txt or s is NULL, this function will simply return, if r is null, s
 * will be cut out of txt (in this case r is modifyed). If s is/contains 
 * a substring of r, this function returns without doing anything.
 */
void expandVars(char** txt,char* s,char* r);

/**
 * Split a string into tokens.
 * @param str the string to split
 * @param idx stop tokenization after finding idx tokens (the rest of the
 * string will be put into the last token, no matter how many whitespaces it 
 * may contain). A value of 0 means: return the complete string, while -1
 * stands for unlimited tokens.
 * @param delim char to
 * @return a NULL terminated array with substrings of str
 */
char **splitString(const char*, int idx, char delim);

/**
 * Read the contents of a file
 * @param fname - name of the file to read
 * @return a pointer do the read in content or NULL
 */
char* readFile(char* fname);

/**
 * Strip anything of a string, that is not an emailaddress.
 * @param d the "dirty" emailaddress. Anything, that does not like like
 * an emaladdress is stripped of. This argument may be nullified/freed
 */
void cleanAddress(char** d);
