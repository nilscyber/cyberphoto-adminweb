#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ldap.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <libgen.h>
#include <gdbm.h>

#ifndef __LCLINT__
#include <syslog.h>
#endif

#include "gnarwl.h"
#include "conf.h"
#include "util.h"
#include "dbaccess.h"

/**
 * These three vars are filled with data by readHeader()
 */
char* sender;
char* subject;
char** receivers;

/**
 * Verbose logging, anyone ?
 */
extern int verbose;

/**
 * This structure holds the data of the config file
 */
extern struct conf cfg;

/**
 * Put a new mail address in the list of recepient mails
 * @pram adr the a copy of adr will be put into the list
 */
void addAddr(const char* adr) {
  char** tmp=NULL;
  char* a;
  int i=0;
  
  if (adr==NULL) return;
  
  a=(char*)calloc(strlen(adr)+1,sizeof(char));
  if (a==NULL) oom();
  strcpy(a,adr);
  
  while(receivers[i]!=NULL) i++;

  tmp=(char**)malloc(2*sizeof(char**)+i*sizeof(char**));
  if (tmp==NULL) oom();
  memcpy(tmp,receivers,i*sizeof(char**));
  tmp[i]=a;
  tmp[i+1]=NULL;
  free(receivers);
  receivers=tmp;
}

/**
 * Analyze mail header
 * @return TRUE if the mail could be replied to
 */ 
int readHeader(void) {
  char buf[MAXLINE];
  GDBM_FILE dbf_f;
  GDBM_FILE dbf_b;
  int line_count=0;
  int addr_count=0;
  char** line=NULL;
  char* tmp=NULL;
  int hrt=0;  // Has Reply To
  
  dbf_f=dbOpen(cfg.mfilter,GDBM_READER);
  if (dbf_f==NULL && (verbose>=LVL_WARN) ) {
    syslog(LOG_MAIL+LOG_INFO,"WARN/IO %s",cfg.mfilter);
  }
  
  dbf_b=dbOpen(cfg.blist,GDBM_READER);
  if (dbf_b==NULL && (verbose>=LVL_WARN) ) { 
    syslog(LOG_MAIL+LOG_INFO,"WARN/IO %s",cfg.blist);
  }
  
  
  // read mail line per line, stop on empty line (marks end of header)
  while (fgets(buf,(int)sizeof(buf),stdin) && (*buf != '\n') ) {
    line_count++;
    
    if ((line_count>=cfg.maxheader)||(addr_count>=cfg.maxmail)) {
      if (verbose>=LVL_DEBUG) 
        syslog(LOG_MAIL+LOG_INFO,"DEBUG/- mail over limit (%d/%d)",line_count,addr_count);
      dbClose(dbf_f);
      dbClose(dbf_b);
      return FALSE;
    }
    
    // strip trailing newline
    buf[strlen(buf)-1]=(char)NULL;

    if(dbContains(buf,dbf_f)) {
      dbClose(dbf_f);
      dbClose(dbf_b);
      if (verbose>=LVL_DEBUG) syslog(LOG_MAIL+LOG_INFO,"DEBUG/- mail filtered");
      return FALSE;
    }
    
    if (tmp!=NULL) { free(tmp); tmp=NULL; }
    
    // If the current line is a continuation of a folded line, add a header.
    if((buf[0]==' ' || buf[0]=='\t') && line[0]!=NULL) {
      tmp=(char*)calloc(MAXLINE+strlen(line[0])+3,sizeof(char));
      if (tmp==NULL) oom();
      strcpy(tmp,line[0]);
      //memcpy(tmp+(strlen(line[0])+1)*sizeof(char),buf,MAXLINE);
      strcat(tmp,buf);
      tmp[strlen(line[0])]=':';
    }
    else {
      tmp=(char*)calloc(MAXLINE,sizeof(char));
      if (tmp==NULL) oom();
      strcpy(tmp,buf);
    }
    
    // Cleanup from previous loop
    if(line!=NULL) {
      if (line[0]!=NULL) { free(line[1]); line[0]=NULL;}
      if (line[1]!=NULL) { free(line[0]); line[1]=NULL;}
    }
    
    
    // Now, lets parse those fields
    line=splitString(tmp,1,':');

    if (line[0]!=NULL && line[1]!=NULL) {
      
      if(!strcasecmp("subject",line[0])) {
        int sc=0;
        if(line[1][0]==' ') sc=1;
        if (subject!=NULL) {
          char *tmp_sub=(char*)malloc(strlen(line[1])+strlen(subject));
          if(tmp==NULL) oom();
          strcpy(tmp_sub,subject);
          //strcpy(tmp_sub+strlen(tmp_sub)-1,line[1]+sc);
          strcat(tmp_sub,line[1]+sc);
          free(subject);
          subject=tmp_sub;
        }
        else {
          subject=(char*)calloc(strlen(line[1])+1,sizeof(char));
          if (subject==NULL) oom();
          strcpy(subject,line[1]+sc);
        }
      }
      
      if(!strcasecmp("from",line[0]) && hrt==0 ) {
        if(sender!=NULL) free(sender);
        cleanAddress(&line[1]);
        sender=(char*)calloc(strlen(line[1])+1,sizeof(char));
        if (sender==NULL) oom();
        strcpy(sender,line[1]);
      }
      
      if(!strcasecmp("reply-to",line[0])) {
        if(sender!=NULL) free(sender);
        cleanAddress(&line[1]);
        sender=(char*)calloc(strlen(line[1])+1,sizeof(char));
        if (sender==NULL) oom();
        strcpy(sender,line[1]);
        hrt=1;
      }
      
      if((!strcasecmp("to",line[0])|| !strcasecmp("cc",line[0])) ) {
        int i=0;
        char** tmp_r=splitString(line[1],-1,',');

        while(tmp_r[i]!=NULL) {
          cleanAddress(&(tmp_r[i]));
          addAddr(tmp_r[i]);
          addr_count++;
          free(tmp_r[i]);
          i++;
        }
      }
    }
    
  }
  if(line!=NULL) {
    if (line[0]!=NULL) { free(line[1]); line[0]=NULL;}
    if (line[1]!=NULL) { free(line[0]); line[1]=NULL;}
  }
     
  dbClose(dbf_f);
  dbClose(dbf_b);
  return TRUE;
}

char *readLDAP(const char* mail) {

  LDAPMessage *res;
  int rc;
  LDAP *ld;
  char *tmp;
  char *tmp2;
  char *vmes=NULL;
  char **entry=NULL;
  int pos;
  struct timeval maxwait;
  
  maxwait.tv_sec=10;
  maxwait.tv_usec=0;

  ld=ldap_init(cfg.server,cfg.port);
  if (ld==NULL) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/LDAP connection failed");
    exit(EXIT_FAILURE);
  }
  rc=ldap_simple_bind_s(ld,cfg.uid,cfg.pwd);
  if (rc!=LDAP_SUCCESS) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/LDAP %s",ldap_err2string(rc));
    exit(EXIT_FAILURE);
  }
  
  tmp=calloc(strlen(cfg.qfilter)+1,sizeof(char));
  strcpy(tmp,cfg.qfilter);
  expandVars(&tmp,cfg.map_receiver,(char*)mail);
  expandVars(&tmp,cfg.map_sender,sender);
  expandVars(&tmp,cfg.map_subject,subject);
  
  rc=ldap_search_st(ld,cfg.base,cfg.scope,tmp,cfg.macro_attr,0,&maxwait,&res);
  if (rc!=LDAP_SUCCESS) {
    if (verbose>=LVL_INFO) {
      syslog(LOG_MAIL+LOG_INFO,"INFO/LDAP Wrong query base?");
    }
    return NULL;
  }
  
  pos=ldap_count_entries(ld,res);
  if (pos>1) {
    if (verbose>=LVL_DEBUG) 
      syslog(LOG_MAIL+LOG_INFO,"DEBUG/LDAP %d entries for: %s -> ignored",pos,tmp);
    return NULL;
  }
  
  if (ldap_count_entries(ld,res)==0 && verbose>=LVL_DEBUG){
    syslog(LOG_MAIL+LOG_INFO,"DEBUG/LDAP No match: %s",tmp);
  }
  
  
  free(tmp);
  tmp=NULL;
  
  
  res=ldap_first_entry(ld,res);
  
  if (res==NULL) { 
    ldap_unbind(ld); 
    return NULL; 
  }
  
  
  entry=ldap_get_values(ld,res,cfg.result);
  if (ldap_count_values(entry)==1) {
    vmes=(char*)calloc(strlen(entry[0])+1,sizeof(char));
    strcpy(vmes,entry[0]);
    ldap_value_free(entry);
  }
  else {
    if (verbose>=LVL_DEBUG) syslog(LOG_MAIL+LOG_INFO,"DEBUG/LDAP %s contains no data",mail);
    ldap_unbind(ld);
    return NULL;
  }
  
  tmp=readFile(cfg.mailheader);
  if (tmp!=NULL) {
    tmp2=(char*)calloc(strlen(tmp)+strlen(vmes)+1,sizeof(char));
    if (tmp2==NULL) oom();
    memcpy(tmp2,tmp,sizeof(char)*strlen(tmp));
    memcpy(tmp2+(strlen(tmp))*sizeof(char),vmes,sizeof(char)*strlen(vmes));
    free(vmes);
    free(tmp);
    vmes=tmp2;
  }
  
  pos=0;
  while(cfg.macro_name[pos]!=NULL) {
    entry=NULL;
    entry=ldap_get_values(ld,res,cfg.macro_attr[pos]);
    if (entry!=NULL) {
      expandVars(&vmes,cfg.macro_name[pos],entry[0]);
      ldap_value_free(entry);
    }
    else expandVars(&vmes,cfg.macro_name[pos],"");
    pos++;
  }
  
  ldap_unbind(ld);
  
  
  expandVars(&vmes,cfg.map_subject,subject);
  expandVars(&vmes,cfg.map_sender,sender);
  expandVars(&vmes,cfg.map_receiver,(char*)mail);
  expandVars(&vmes,"\\n","\n");
  return vmes;
}

void doReply(char* addr, char* body) {
  int p[2];
  int c;
  char* tmp;
  FILE *desc;
  
  if (pipe(p)!=0) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/MTA pipe to MTA failed");
    exit(EXIT_FAILURE);
  }
  
  c=fork();
  if (c<0) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/MTA couldn't fork MTA");
    exit(EXIT_FAILURE);
  }
  
  if (c==0) {
    (void)dup2(p[0],0);
    (void)close(p[0]);
    (void)close(p[1]);
    
    tmp=(char*)calloc(strlen(cfg.mta)+strlen(cfg.mta_opts)+3,sizeof(char));
    if(tmp==NULL) oom();
    strcpy(tmp,cfg.mta);
    tmp[strlen(cfg.mta)]=' ';
    strcpy(tmp+strlen(cfg.mta)+sizeof(char),cfg.mta_opts);
    
    expandVars(&tmp,cfg.map_sender,sender);
    expandVars(&tmp,cfg.map_receiver,addr);
    
    (void)execv(cfg.mta,splitString(tmp,-1,' '));
    syslog(LOG_MAIL+LOG_INFO,"CRIT/MTA %s",tmp);
    exit(EXIT_FAILURE);
  }
  close(p[0]);
  desc=fdopen(p[1],"w");
  fprintf(desc,body);
  fclose(desc);
  if (verbose>=LVL_INFO) {
    syslog(LOG_MAIL+LOG_INFO,"INFO/- sent mail: %s -> %s",addr, sender);
  }
  if(tmp!=NULL) free(tmp);
}

void printUsage(void) {
  
  printf("\nGNARWL(v%s) - Gnu Neat Auto Reply With LDAP\n\n\
  Read email through stdin, reply to it, if nescessary\n\
  Options:\n\n\t-h\t\tprint help\n\t-c <cfgfile>\tuse configfile\
  (default: %s)\n\n",VERSION,CFGFILE);
  
  exit(EXIT_SUCCESS);
}
 
int main(int argc, char **argv) {
  int ch;
  char* cfg_file;
  char* rep=NULL;
  
  cfg_file=CFGFILE;
  receivers=(char**)calloc(1,sizeof(char**));
  if (receivers==NULL) oom();
  
  while ((ch = getopt(argc, argv, "hc:")) != EOF) {
    switch((char)ch) {
      case 'h': printUsage(); break;
      case 'c': cfg_file=optarg;break;
    }
  }
  openlog("gnarwl",LOG_PID,LOG_MAIL);
  readConf(cfg_file);
  if (readHeader()==FALSE) exit(EXIT_SUCCESS);
  
  ch=0;
  
  while(receivers[ch]!=NULL && sender!=NULL) {
    rep=readLDAP(receivers[ch]);
    if (rep!=NULL) {
      if (dbCheck(sender,receivers[ch])) {
        dbLock(sender,receivers[ch]);
        doReply(receivers[ch],rep);
      }
      else {
        if (verbose>=LVL_DEBUG) {
          syslog(LOG_MAIL+LOG_INFO,"DEBUG/- blocked: %s -> %s",sender,receivers[ch]);
        }
      }
      free(rep);
    }
    ch++;
  }

  closelog();
  return EXIT_SUCCESS;
}
