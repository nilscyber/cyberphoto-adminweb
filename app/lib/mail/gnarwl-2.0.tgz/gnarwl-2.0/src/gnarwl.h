// Create new files with this umask
#define DB_UMASK 0644
//multiply config directive "db_expire" with this value
#define TIMEFACTOR 3600

// Defaults for several config directives
#define DEFAULT_SERVER "localhost"
#define DEFAULT_QFILTER "(&(mail=$recepient)(vacationActive=TRUE)"
#define DEFAULT_MES "vacationInfo"
#define DEFAULT_BASE "o=home"
#define DEFAULT_DBDIR "/var/lib/gnarwl/db/"
#define DEFAULT_MTA "/usr/bin/sendmail"
#define DEFAULT_DBEXP 48
#define DEFAULT_MAIL_LIMIT 256
#define DEFAULT_MAP_SENDER "$sender"
#define DEFAULT_MAP_RECEIVER "$recepient"
#define DEFAULT_MAP_SUBJECT "$subject"

#define LVL_CRIT 0
#define LVL_WARN 1
#define LVL_INFO 2
#define LVL_DEBUG 3

#define TRUE 1
#define FALSE 0
#define MAXLINE 255
#ifndef CFGFILE
#define CFGFILE "gnarwl.cfg"
#endif
#ifndef VERSION
#define VERSION " <unknown>"
#endif

/**
 * Add an address to the list of addresses
 * @param adr Address to add
 */
void addAddr(const char* adr);

/**
 * Read from stdin, until an empty line is encountered
 * @return TRUE parsing well, FALSE something about the header is not in
 * proper order - ignore this mail.
 */
int readHeader(void);

/**
 * Read data from LDAP
 * @param adr the (local) mailaddress that is to be looked up
 * @return a struct containing adr + mailbody, or NULL
 */
char *readLDAP(const char* adr);

/**
 * Actually send out a mail
 * @param addr the address to reply from
 * @param body body of the mail
 */
void doReply(char* addr, char* body);

/**
 * Print usage information and exit
 */
void printUsage(void);

/**
 * Well, main! What do you expect, it does?
 */
int main(int,char**); 

