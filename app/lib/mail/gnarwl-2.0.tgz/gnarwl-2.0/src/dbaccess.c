#include <stdlib.h>
#include <gdbm.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include "gnarwl.h"
#include "conf.h"
#include "util.h"
#include "dbaccess.h"

#ifndef __LCLINT__
#include <syslog.h>
#endif

extern struct conf cfg;
extern int verbose;

int dbCheck( char* she, char* me) {
  GDBM_FILE dbf=NULL;
  char *fname;
  datum data;
  datum key;
  time_t t;
  
  fname=calloc(strlen(me)+strlen(cfg.dbdir)+5,sizeof(char));
  if (fname==NULL) oom();
  strcpy(fname,cfg.dbdir);
  if (fname[strlen(fname)-1]!='/') fname[strlen(fname)]='/';
  strcpy(fname+strlen(fname),me);
  dbf=dbOpen(fname,GDBM_READER);
  if (dbf==NULL) dbf=dbOpen(fname,GDBM_WRCREAT);
  if (dbf==NULL) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/IO %s",fname);
    exit(EXIT_FAILURE);
  }
  
  key.dptr=she;
  key.dsize=(int)strlen(she);
  data=gdbm_fetch(dbf,key);
  if (data.dptr==NULL) {
    gdbm_close(dbf);
    free(fname);
    return TRUE;
  }
  gdbm_close(dbf);
  memcpy(&t,data.dptr,sizeof(t));
  free(fname);
  if (time(NULL)-t>TIMEFACTOR*cfg.dbexp) return TRUE;
  return FALSE;
}

void dbLock( char* he, char* me) {
  GDBM_FILE dbf;
  char *fname;
  datum key;
  datum data;
  time_t ret;
  
  fname=calloc(strlen(me)+strlen(cfg.dbdir)+5,sizeof(char));
  if (fname==NULL) oom();
  strcpy(fname,cfg.dbdir);
  if (fname[strlen(fname)-1]!='/') fname[strlen(fname)]='/';
  strcpy(fname+strlen(fname),me);

  dbf=gdbm_open(fname,0,GDBM_WRITER,DB_UMASK,NULL);
  
  if (dbf==NULL) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/IO %s",fname);
    exit(EXIT_FAILURE);
  }
  
  key.dptr=he;
  key.dsize=strlen(he);
  ret=time(NULL);
  data.dptr=(char*)malloc(sizeof(ret));
  if (data.dptr==NULL) oom();
  memcpy(data.dptr,&ret,sizeof(ret));
  data.dsize=(int)sizeof(ret);
  free(fname);
  if (gdbm_store(dbf,key,data,GDBM_REPLACE)!=0) {
    gdbm_close(dbf);
    syslog(LOG_MAIL+LOG_DEBUG,"CRIT/IO %s",me);
    exit (EXIT_FAILURE);
  }
  gdbm_close(dbf);
}


GDBM_FILE dbOpen( char* fname, int mode) {
  GDBM_FILE dbf;
  int retrycount=0;
  struct stat fs;
  
  if (fname==NULL) return NULL;
  
  if ( (mode==GDBM_READER) && (stat(fname,&fs)==-1) ) return NULL;
  
  do {
    dbf=gdbm_open(fname,0,mode,DB_UMASK,NULL);
    if (dbf!=NULL) break;
    retrycount++;
    sleep(1+(int) (10.0*rand()/(RAND_MAX+1.0)));
  }
  while ((errno == EAGAIN) && (retrycount<=10));
  
  return dbf;
}

void dbClose(GDBM_FILE dbf_ptr) {
  if (dbf_ptr==NULL) return;
  gdbm_close(dbf_ptr);
  dbf_ptr=NULL;
}

int dbContains(char* str_ptr, GDBM_FILE dbf_ptr) {
  datum key;
  
  if ((str_ptr==NULL) || (dbf_ptr==NULL)) return FALSE;
  key.dptr=str_ptr;
  key.dsize=(int)strlen(key.dptr)+1;
  if (gdbm_exists(dbf_ptr,key)) return TRUE;
  return FALSE;
}
