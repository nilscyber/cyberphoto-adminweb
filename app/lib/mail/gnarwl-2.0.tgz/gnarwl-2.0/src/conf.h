/**
 * Holds the data of the config file
 */
struct conf {
  char *base;
  char *uid;
  char *pwd;
  char *server;
  char *qfilter;
  char *mfilter;
  char *result;
  char *dbdir;
  char *mta;
  char *mta_opts;
  char *blist;
  char *mailheader;
  char *map_sender;
  char *map_receiver;
  char *map_subject;
  char **macro_attr;
  char **macro_name;
  int scope;
  int port;
  int dbexp;
  int maxmail;
  int maxheader;
};

/**
 * Enter a key/value pair into the config structure
 * @param key the keyword from the configfile
 * @param val the value of the keyword from the configfile
 */
void putEntry(char*, char*);

/**
 * Fill the configstructure with default values
 */
void setDefaults(void);

/**
 * Fill the configstructure with values from a configfile
 * @param fname name of the configfile
 */
void readConf(char*);
