#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ldap.h>

#ifndef __LCLINT__
#include <syslog.h>
#endif

#include "gnarwl.h"
#include "conf.h"
#include "util.h"

struct conf cfg;
int verbose=LVL_CRIT;

void putEntry(char* key, char* val) {
  
  if (!strcasecmp(key,"ldap_uid")) {
    cfg.uid=val;
    return;
  }
  if (!strcasecmp(key,"ldap_pwd")) {
    cfg.pwd=val;
    return;
  }
  if (!strcasecmp(key,"mail_filter")) {
    cfg.mfilter=val;
    return;
  }
  if (!strcasecmp(key,"mail_blacklist")) {
    cfg.blist=val;
    return;
  }
  if (!strcasecmp(key,"reply_header")) {
    cfg.mailheader=val;
    return;
  }
  
  // val may not be NULL below
  
  if (!strcasecmp(key,"ldap_map")) {
    char **tmp;
    int pos=0;
    char **entry=splitString(val,1,' ');
    
    if (entry[1]==NULL) return;
    while(cfg.macro_attr[pos]!=NULL) pos++;
    tmp=(char**)calloc(sizeof(char**)*2+pos*sizeof(char**),sizeof(char**));
    if (tmp==NULL) oom();
    memcpy(tmp,cfg.macro_attr,sizeof(char**)*pos);
    tmp[pos]=entry[0];
    free(cfg.macro_attr);
    cfg.macro_attr=tmp;
    
    tmp=(char**)calloc(sizeof(char**)*2+pos*sizeof(char**),sizeof(char**));
    if (tmp==NULL) oom();
    memcpy(tmp,cfg.macro_name,sizeof(char**)*pos);
    tmp[pos]=entry[1];
    free(cfg.macro_name);
    cfg.macro_name=tmp;
    free(val);
    val=NULL;
  }
  
  if (!strcasecmp(key,"ldap_server")) {
    cfg.server=val;
    return;
  }
  if (!strcasecmp(key,"ldap_port")) {
    cfg.port=atoi(val);
    return;
  }
  if (!strcasecmp(key,"ldap_scope")) {
    if (!strcasecmp(val,"base")) cfg.scope=LDAP_SCOPE_BASE;
    if (!strcasecmp(val,"one")) cfg.scope=LDAP_SCOPE_ONELEVEL;
    if (!strcasecmp(val,"sub")) cfg.scope=LDAP_SCOPE_SUBTREE;
    return;                                                                     
  }
  if (!strcasecmp(key,"ldap_base")) {
    cfg.base=val;
    return;
  }
  if (!strcasecmp(key,"ldap_filter")) {
    cfg.qfilter=val;
    return;
  }
  if (!strcasecmp(key,"ldap_result")) {
    cfg.result=val;
    return;
  }
  if (!strcasecmp(key,"map_sender")) {
    cfg.map_sender=val;
    return;
  }
  if (!strcasecmp(key,"map_receiver")) {
    cfg.map_receiver=val;
    return;
  }
  if (!strcasecmp(key,"db_dir")) {
    cfg.dbdir=val;
    return;
  }
  if (!strcasecmp(key,"db_expire")) {
    cfg.dbexp=atoi(val);
    return;
  }
  if (!strcasecmp(key,"mail_mta")) {
    char** tmp=splitString(val,1,' ');
    free(val);
    val=NULL;
    cfg.mta=(char*)calloc(strlen(tmp[0])+1,sizeof(char));
    if (cfg.mta==NULL) oom();
    strcpy(cfg.mta,tmp[0]);
    if (tmp[1]==NULL) {cfg.mta_opts=""; free(tmp); return;}
    //cfg.mta_opts=(char*)calloc(strlen(tmp[1])+1,sizeof(char));
    //if (cfg.mta_opts==NULL) oom();
    //strcpy(cfg.mta_opts,tmp[1]);
    cfg.mta_opts=tmp[1];
    return;
  }
  if (!strcasecmp(key,"mail_subject")) {
    cfg.map_subject=val;
    return;
  }
  if (!strcasecmp(key,"mail_limit_receivers")) {
    cfg.maxmail=atoi(val);
    return;
  }
  if (!strcasecmp(key,"mail_limit_header")) {
    cfg.maxheader=atoi(val);
    return;
  }
  if (!strcasecmp(key,"log_level")) {
    verbose=atoi(val);
    return;
  }
}

void setDefaults(void) {
  cfg.base=DEFAULT_BASE;
  cfg.uid=NULL;
  cfg.pwd=NULL;
  cfg.server=DEFAULT_SERVER;
  cfg.qfilter=DEFAULT_QFILTER;
  cfg.mfilter=NULL;
  cfg.scope=LDAP_SCOPE_SUBTREE;
  cfg.port=LDAP_PORT;
  cfg.dbdir=DEFAULT_DBDIR;
  cfg.dbexp=DEFAULT_DBEXP;
  cfg.mta=DEFAULT_MTA;
  cfg.blist=NULL;
  cfg.maxmail=DEFAULT_MAIL_LIMIT;
  cfg.maxheader=DEFAULT_MAIL_LIMIT;
  cfg.result=DEFAULT_MES;
  cfg.map_sender=DEFAULT_MAP_SENDER;
  cfg.map_receiver=DEFAULT_MAP_RECEIVER;
  cfg.map_subject=DEFAULT_MAP_SUBJECT;
  cfg.macro_attr=(char**)calloc(1,sizeof(char**));
  cfg.macro_name=(char**)calloc(1,sizeof(char**));
  if (cfg.macro_attr==NULL || cfg.macro_name==NULL) oom();
}

void readConf(char *cfile) {
  FILE *fptr;
  char buf[MAXLINE];
  char** tmp;
  int pos=0;

  setDefaults();
  fptr=fopen(cfile,"r");
  if (fptr==NULL) {
    syslog(LOG_MAIL+LOG_INFO,"CRIT/IO %s",cfile);
    exit(EXIT_FAILURE);
  }
  while(((fgets(buf, (size_t)sizeof(buf), fptr)) && (buf != NULL))) {
    if (!((buf[0]=='#') || (*buf=='\n'))) { 
      if (buf[strlen(buf)-1]=='\n') buf[strlen(buf)-1]=(char)NULL;
      tmp=splitString(buf,1,' ');
      //printf("%s:%s\n",tmp[0],tmp[1]);
      if (tmp[1]!=NULL) putEntry(tmp[0],tmp[1]);
      else putEntry(tmp[0],"");
      free(tmp[0]);
    }
  }
  (void)fclose(fptr);
  
  while(cfg.macro_attr[pos]!=NULL) pos++;
  tmp=(char**)calloc(sizeof(char**)*2+pos*sizeof(char**),sizeof(char**));
  if (tmp==NULL) oom();
  memcpy(tmp,cfg.macro_attr,sizeof(char**)*pos);
  tmp[pos]=cfg.result;
  free(cfg.macro_attr);
  cfg.macro_attr=tmp;
}
